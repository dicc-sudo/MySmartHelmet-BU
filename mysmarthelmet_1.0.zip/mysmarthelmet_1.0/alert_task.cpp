#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <time.h>
#include "ipc.h"
#include "config.h"

static void getTimestamp(char *buf, size_t len) {
    struct tm ti;
    if (!getLocalTime(&ti, 2000)) { strncpy(buf, "N/A", len); return; }
    strftime(buf, len, "%d/%m/%Y %H:%M:%S", &ti);
}

// สร้าง/ทำลาย WiFiClientSecure ทุกครั้งที่ส่ง
// เพื่อหลีกเลี่ยง static global ขนาดใหญ่ที่ init ก่อน setup()
static void sendLine(const char *msg) {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("[LINE] no WiFi");
        return;
    }

    // escape \n → \\n
    char escaped[512];
    size_t j = 0;
    for (size_t i = 0; msg[i] && j < sizeof(escaped) - 3; i++) {
        if (msg[i] == '\n') { escaped[j++] = '\\'; escaped[j++] = 'n'; }
        else                 { escaped[j++] = msg[i]; }
    }
    escaped[j] = '\0';

    char body[640];
    snprintf(body, sizeof(body),
        "{\"to\":\"" LINE_USER_ID "\","
        "\"messages\":[{\"type\":\"text\",\"text\":\"%s\"}]}", escaped);

    // heap-allocate → ไม่กิน task stack, ไม่ใช่ static global
    WiFiClientSecure *client = new WiFiClientSecure();
    client->setInsecure();
    HTTPClient http;
    http.begin(*client, LINE_API_URL);
    http.addHeader("Content-Type", "application/json");
    http.addHeader("Authorization", "Bearer " LINE_TOKEN);
    http.setTimeout(8000);
    int code = http.POST(body);
    Serial.printf("[LINE] HTTP %d\n", code);
    http.end();
    delete client;
}

void vAlertTask(void *pv) {
    char tsbuf[32];
    char msgbuf[400];

    for (;;) {
        xEventGroupWaitBits(xAlertEvents,
            FALL_BIT, pdFALSE, pdTRUE, portMAX_DELAY);

        Serial.println("[ALERT] fall — starting");
        Serial.printf("[ALERT] stack HWM: %d words\n",
                      uxTaskGetStackHighWaterMark(NULL));

        // ── ข้อความที่ 1 ──────────────────────────────────────
        getTimestamp(tsbuf, sizeof(tsbuf));
        snprintf(msgbuf, sizeof(msgbuf),
            "🚨 [MySmartHelmet]\nตรวจพบการกระแทก!\n⏰ %s\n⚠️ รอ 15 วิ...", tsbuf);
        sendLine(msgbuf);

        // ── รอ 15 วิ หรือกดยกเลิก ────────────────────────────
        EventBits_t result = xEventGroupWaitBits(
            xAlertEvents, CANCEL_BIT,
            pdTRUE, pdTRUE, pdMS_TO_TICKS(ALERT_COUNTDOWN_MS));

        bool cancelled = (result & CANCEL_BIT) != 0;
        xEventGroupClearBits(xAlertEvents, FALL_BIT);

        // ── snapshot sensor ───────────────────────────────────
        dist_data_t dd = {};
        temp_data_t td = {};
        imu_data_t  id = {};
        xQueuePeek(xDistQueue, &dd, 0);
        xQueuePeek(xTempQueue, &td, 0);
        xQueuePeek(xIMUQueue,  &id, 0);

        // ── ข้อความที่ 2 ──────────────────────────────────────
        if (cancelled) {
            sendLine("🟢 [MySmartHelmet]\nกดยกเลิกแล้ว ไม่ต้องการความช่วยเหลือ");
        } else {
            getTimestamp(tsbuf, sizeof(tsbuf));
            snprintf(msgbuf, sizeof(msgbuf),
                "🆘 [MySmartHelmet วิกฤต!]\nไม่มีการตอบสนอง โปรดช่วยด่วน!\n"
                "IMU:%.2f %.2f %.2f g\nระยะ:%d mm อุณหภูมิ:%.1fC\nเวลา:%s",
                id.ax_f, id.ay_f, id.az_f,
                dd.distance_mm, td.temp_c, tsbuf);
            sendLine(msgbuf);
        }

        if (xSemaphoreTake(xAlertMutex, portMAX_DELAY) == pdTRUE) {
            gIsAlerting = false;
            xSemaphoreGive(xAlertMutex);
        }
        Serial.println("[ALERT] done");
        vTaskDelay(pdMS_TO_TICKS(3000));
    }
}
