/*
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  MySmartHelmet — Embedded Systems Project                    ║
 * ║  BU / FreeRTOS + Interrupt + Semaphore + IoT (LINE)          ║
 * ╠══════════════════════════════════════════════════════════════╣
 * ║  Board   : ESP32-C3                                          ║
 * ║  Sensors : MPU6050 (IMU), VL53L0X (laser dist), NTC 3950     ║
 * ║  Output  : Passive Buzzer, LINE Notify (IoT)                 ║
 * ║  Interrupt: BUTTON_PIN (FALLING) → cancel fall alert         ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <time.h>
#include "config.h"
#include "ipc.h"
#include "mpu6050_driver.h"

// ─── External Task Declarations (อ้างอิงจากไฟล์ .cpp อื่นๆ) ───
extern void vIMUReaderTask(void *pv);
extern void vFallDetectTask(void *pv);
extern void vDistanceTask(void *pv);
extern void vTempTask(void *pv);
extern void vBuzzerTask(void *pv);
extern void vAlertTask(void *pv);
extern void vMonitorTask(void *pv);
extern void vl53l0xInit();

// ─── Global IPC Handles (กำหนดค่าตัวแปรตาม ipc.h) ─────────────
QueueHandle_t      xIMUQueue;
QueueHandle_t      xDistQueue;
QueueHandle_t      xTempQueue;
QueueHandle_t      xSnapshotQueue;

SemaphoreHandle_t  xWireMutex;
SemaphoreHandle_t  xAlertMutex;
EventGroupHandle_t xAlertEvents;

// ตัวแปรสำหรับป้องกันการส่งแจ้งเตือนซ้ำซ้อน
volatile bool gIsAlerting = false; 

// ─── Interrupt Service Routine (ISR) สำหรับปุ่ม Cancel ────────
void IRAM_ATTR handleButton() {
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    // ส่ง Event Bit ไปยัง Task ว่ามีการกดปุ่ม
    xEventGroupSetBitsFromISR(xAlertEvents, CANCEL_BIT, &xHigherPriorityTaskWoken);
    
    // บังคับให้สลับไปทำงาน Task ที่สำคัญกว่าทันที (Real-time response)
    if (xHigherPriorityTaskWoken) {
        portYIELD_FROM_ISR();
    }
}

// ─── Setup Function ───────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n\n--- [BOOT] MySmartHelmet Starting ---");

    // 1. สร้าง IPC (Queues, Mutex, EventGroup) ให้เสร็จก่อน
    xIMUQueue      = xQueueCreate(5, sizeof(imu_data_t));
    xDistQueue     = xQueueCreate(1, sizeof(dist_data_t));
    xTempQueue     = xQueueCreate(1, sizeof(temp_data_t));
    xSnapshotQueue = xQueueCreate(1, sizeof(sensor_snapshot_t));

    xWireMutex   = xSemaphoreCreateMutex();
    xAlertMutex  = xSemaphoreCreateMutex();
    xAlertEvents = xEventGroupCreate();

    // 2. ตั้งค่าปุ่มกด และเปิดใช้งาน Interrupt (รับคะแนน +5%)
    pinMode(PIN_BUTTON, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(PIN_BUTTON), handleButton, FALLING);

    // 3. เริ่มต้น I2C สำหรับ Sensors (ขา 4, 5 ของ ESP32-C3)
    Wire.begin(PIN_SDA, PIN_SCL);

    // 4. ตั้งค่า Buzzer (รองรับ ESP32 Core รุ่นใหม่)
    #if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
        ledcAttach(PIN_BUZZER, 2000, 8);
    #else
        ledcSetup(0, 2000, 8);
        ledcAttachPin(PIN_BUZZER, 0);
    #endif

    // 5. เชื่อมต่อ WiFi ให้สำเร็จ **ก่อน** สร้าง Task (แก้ปัญหา return error)
    // Serial.printf("[BOOT] Connecting to WiFi: %s ", WIFI_SSID);
    // WiFi.mode(WIFI_STA);
    // WiFi.begin(WIFI_SSID, WIFI_PASS);
    
    // while (WiFi.status() != WL_CONNECTED) {
    //     delay(500);
    //     Serial.print(".");
    // }
    // Serial.println("\n[BOOT] WiFi Connected!");
    // Serial.print("[BOOT] IP Address: ");
    // Serial.println(WiFi.localIP());

    // 6. ซิงค์เวลา (NTP)
    configTime(NTP_GMT_OFFSET, 0, NTP_SERVER1, NTP_SERVER2);
    Serial.println("[BOOT] NTP sync requested");

    // 7. เริ่มต้นใช้งาน Sensors
    mpu6050Init();
    vl53l0xInit();

    // 8. สั่งรัน FreeRTOS Tasks 
    Serial.printf("[BOOT] Free heap before tasks: %d bytes\n", esp_get_free_heap_size());

    // ลำดับความสำคัญของ Task (ยิ่งสูงยิ่งสำคัญ)
    #define PRI_IMU      5
    #define PRI_FALL     4
    #define PRI_DISTANCE 3
    #define PRI_TEMP     3
    #define PRI_BUZZER   2
    #define PRI_ALERT    2
    #define PRI_MONITOR  1

// Tasks อ่านเซนเซอร์ (เพิ่มจาก 2048 เป็น 4096 ให้หมด เพื่อรองรับ Math functions)
    xTaskCreate(vIMUReaderTask,  "imu",   4096, NULL, PRI_IMU,      NULL);
    xTaskCreate(vFallDetectTask, "fall",  4096, NULL, PRI_FALL,     NULL);
    xTaskCreate(vDistanceTask,   "dist",  4096, NULL, PRI_DISTANCE, NULL);
    xTaskCreate(vTempTask,       "temp",  4096, NULL, PRI_TEMP,     NULL); // <-- ตัวปัญหาแก้ตรงนี้
    
    // Task เสียงเตือน ใช้แค่นี้พอเพราะแค่สั่งเปิดปิดขา Digital
    xTaskCreate(vBuzzerTask,     "buz",   2048, NULL, PRI_BUZZER,   NULL);
    
    // Task Network ใช้ 8192 ถูกต้องแล้ว
    xTaskCreate(vAlertTask,      "alrt",  8192, NULL, PRI_ALERT,    NULL);
    xTaskCreate(vMonitorTask,    "mon",   8192, NULL, PRI_MONITOR,  NULL);

    Serial.println("[BOOT] All tasks started successfully.");
}

// ─── Loop Function ────────────────────────────────────────────
void loop() {
    // ตามโจทย์บังคับ: ห้ามมีการ Polling ใน loop()
    // ลบ Task นี้ทิ้งเพื่อคืนหน่วยความจำให้ระบบนำไปใช้กับ FreeRTOS Task อื่น
    vTaskDelete(NULL);
}