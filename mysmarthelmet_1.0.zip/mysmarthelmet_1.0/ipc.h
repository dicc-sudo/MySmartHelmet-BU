#pragma once
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"

// ─────────────────────────────────────────────
//  Data structs ที่ส่งผ่าน Queue
// ─────────────────────────────────────────────

typedef struct {
    float ax, ay, az;        // raw accel (g)
    float gx, gy, gz;        // raw gyro (deg/s)
    float ax_f, ay_f, az_f;  // LPF filtered accel
    uint32_t ts;             // xTaskGetTickCount()
} imu_data_t;

typedef struct {
    uint16_t distance_mm;    // VL53L0X measurement
    uint32_t ts;
} dist_data_t;

typedef struct {
    float temp_c;            // NTC temperature °C
    uint32_t ts;
} temp_data_t;

// snapshot ของ sensor ทั้งหมด ส่งไป LINE ตอน alert ระดับ 2
typedef struct {
    float    ax_f, ay_f, az_f;
    // uint16_t dist_mm;
    float    distance;
    float    temp_c;
    char     timestamp[32];
} sensor_snapshot_t;

// ─────────────────────────────────────────────
//  IPC handles — define ครั้งเดียวใน .ino
// ─────────────────────────────────────────────
extern QueueHandle_t      xIMUQueue;       // imu_data_t
extern QueueHandle_t      xDistQueue;      // dist_data_t
extern QueueHandle_t      xTempQueue;      // temp_data_t
extern QueueHandle_t      xSnapshotQueue;  // sensor_snapshot_t (depth 1)

extern SemaphoreHandle_t  xWireMutex;      // I2C bus guard (MPU6050 + VL53L0X)
extern SemaphoreHandle_t  xAlertMutex;     // ป้องกัน isAlerting race

extern EventGroupHandle_t xAlertEvents;

// ─────────────────────────────────────────────
//  Event bits
// ─────────────────────────────────────────────
#define FALL_BIT      BIT0   // fall detected → trigger alert sequence
#define DIST_WARN_BIT BIT1   // object too close
#define TEMP_WARN_BIT BIT2   // temperature too high
#define CANCEL_BIT    BIT3   // user pressed cancel button (set by ISR→task)

// ─────────────────────────────────────────────
//  Shared state (guarded by xAlertMutex)
// ─────────────────────────────────────────────
extern volatile bool gIsAlerting;    // true ระหว่างช่วงนับถอยหลัง 15 วิ
