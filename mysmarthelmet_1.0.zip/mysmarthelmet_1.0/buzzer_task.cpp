// #include <Arduino.h>
// #include "ipc.h"
// #include "config.h"

// // ESP32 Arduino core ≥ 3.x เปลี่ยน API:
// //   ledcSetup + ledcAttachPin  → ledcAttach(pin, freq, res)
// //   ledcWrite(ch, duty)        → ledcWrite(pin, duty)
// // ใช้ PIN_BUZZER โดยตรงแทน channel number
// static void buzzerOn()  { ledcWrite(PIN_BUZZER, 128); }
// static void buzzerOff() { ledcWrite(PIN_BUZZER, 0); }

// // รูปแบบ beep ต่างกันตามประเภทการแจ้งเตือน
// // Fall: 3 beep สั้น-สั้น-ยาว (SOS-like)  — ฉุกเฉินที่สุด
// // Dist: 2 beep สั้นต่อเนื่อง              — ระยะใกล้
// // Temp: 1 beep ยาว                        — heat warning

// static void patternFall() {
//     // Short-Short-Long
//     const int pat[][2] = {{200,100},{200,100},{600,400}};
//     for (auto &p : pat) {
//         buzzerOn();  vTaskDelay(pdMS_TO_TICKS(p[0]));
//         buzzerOff(); vTaskDelay(pdMS_TO_TICKS(p[1]));
//     }
// }

// static void patternDist() {
//     for (int i = 0; i < 2; i++) {
//         buzzerOn();  vTaskDelay(pdMS_TO_TICKS(150));
//         buzzerOff(); vTaskDelay(pdMS_TO_TICKS(150));
//     }
// }

// static void patternTemp() {
//     buzzerOn();  vTaskDelay(pdMS_TO_TICKS(800));
//     buzzerOff(); vTaskDelay(pdMS_TO_TICKS(200));
// }

// // ─── Task: Buzzer (Priority PRI_BUZZER) ───────────────────────
// // รอ event จาก xAlertEvents แล้วส่งเสียงรูปแบบตามประเภท
// // ใช้ xEventGroupWaitBits รอ ANY bit → ไม่มี busy-wait
// // Priority สูงกว่า Alert เพื่อให้เสียงดังทันที
// void vBuzzerTask(void *pv) {
//     const EventBits_t WATCH = FALL_BIT | DIST_WARN_BIT | TEMP_WARN_BIT;

//     for (;;) {
//         EventBits_t bits = xEventGroupWaitBits(
//             xAlertEvents,
//             WATCH,
//             pdFALSE,       // ไม่ clear — Alert task / sensor task จัดการเอง
//             pdFALSE,       // ANY bit
//             portMAX_DELAY
//         );

//         if (bits & FALL_BIT) {
//             patternFall();
//         } else if (bits & DIST_WARN_BIT) {
//             patternDist();
//         } else if (bits & TEMP_WARN_BIT) {
//             patternTemp();
//         }

//         // throttle — ไม่ให้เสียงดังถี่เกินไปขณะ event ค้างอยู่
//         vTaskDelay(pdMS_TO_TICKS(500));
//     }
// }

#include <Arduino.h>
#include "ipc.h"
#include "config.h"

// ─── เปลี่ยนจาก PWM เป็นสั่งงานแบบ Digital สำหรับ Active Buzzer ───
// หมายเหตุ: Active buzzer ส่วนใหญ่ทำงานแบบ Active-HIGH (HIGH=ดัง)
// แต่ถ้าของคูณเป็นแบบ Active-LOW ให้สลับ HIGH กับ LOW ตรงนี้นะครับ
static void buzzerOn()  { digitalWrite(PIN_BUZZER, HIGH); }
static void buzzerOff() { digitalWrite(PIN_BUZZER, LOW); }

// รูปแบบ beep ต่างกันตามประเภทการแจ้งเตือน
// Fall: 3 beep สั้น-สั้น-ยาว (SOS-like)  — ฉุกเฉินที่สุด
// Dist: 2 beep สั้นต่อเนื่อง              — ระยะใกล้
// Temp: 1 beep ยาว                        — heat warning

static void patternFall() {
    // Short-Short-Long
    const int pat[][2] = {{200,100},{200,100},{600,400}};
    for (auto &p : pat) {
        buzzerOn();  vTaskDelay(pdMS_TO_TICKS(p[0]));
        buzzerOff(); vTaskDelay(pdMS_TO_TICKS(p[1]));
    }
}

static void patternDist() {
    for (int i = 0; i < 2; i++) {
        buzzerOn();  vTaskDelay(pdMS_TO_TICKS(150));
        buzzerOff(); vTaskDelay(pdMS_TO_TICKS(150));
    }
}

static void patternTemp() {
    buzzerOn();  vTaskDelay(pdMS_TO_TICKS(800));
    buzzerOff(); vTaskDelay(pdMS_TO_TICKS(200));
}

// ─── Task: Buzzer (Priority PRI_BUZZER) ───────────────────────
// รอ event จาก xAlertEvents แล้วส่งเสียงรูปแบบตามประเภท
// ใช้ xEventGroupWaitBits รอ ANY bit → ไม่มี busy-wait
// Priority สูงกว่า Alert เพื่อให้เสียงดังทันที
void vBuzzerTask(void *pv) {
    const EventBits_t WATCH = FALL_BIT | DIST_WARN_BIT | TEMP_WARN_BIT;

    for (;;) {
        EventBits_t bits = xEventGroupWaitBits(
            xAlertEvents,
            WATCH,
            pdFALSE,       // ไม่ clear — Alert task / sensor task จัดการเอง
            pdFALSE,       // ANY bit
            portMAX_DELAY
        );

        if (bits & FALL_BIT) {
            patternFall();
        } else if (bits & DIST_WARN_BIT) {
            patternDist();
        } else if (bits & TEMP_WARN_BIT) {
            patternTemp();
        }

        // throttle — ไม่ให้เสียงดังถี่เกินไปขณะ event ค้างอยู่
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}
