#include <Arduino.h>
#include "ipc.h"
#include "config.h"
#include "mpu6050_driver.h"

// LPF state — persistent ระหว่าง iterations
static float lx = 0.0f, ly = 0.0f, lz = 0.0f;

static void lpfUpdate(imu_data_t *d) {
    lx = LPF_ALPHA * d->ax + (1.0f - LPF_ALPHA) * lx;
    ly = LPF_ALPHA * d->ay + (1.0f - LPF_ALPHA) * ly;
    lz = LPF_ALPHA * d->az + (1.0f - LPF_ALPHA) * lz;
    d->ax_f = lx;
    d->ay_f = ly;
    d->az_f = lz;
}

// ─── Task: IMU Reader (Priority PRI_IMU) ───────────────────────
// อ่านแรงสั่นสะเทือนจาก MPU6050 ทุก IMU_POLL_MS ms
// ส่งข้อมูลไปยัง xIMUQueue เพื่อให้ FallDetect Task วิเคราะห์
// ใช้ vTaskDelayUntil() ให้ rate คงที่ ไม่มี busy-wait
void vIMUReaderTask(void *pv) {
    // warm-up: อ่านทิ้งก่อน 1 รอบ ป้องกัน spike แรก
    imu_data_t dummy;
    mpu6050Read(&dummy);
    lx = dummy.ax; ly = dummy.ay; lz = dummy.az;

    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xPeriod = pdMS_TO_TICKS(IMU_POLL_MS);

    for (;;) {
        vTaskDelayUntil(&xLastWakeTime, xPeriod);   // periodic — ไม่ busy-wait

        imu_data_t d;
        if (!mpu6050Read(&d)) {
            Serial.println("[IMU] read error");
            continue;
        }

        lpfUpdate(&d);

        // ส่งเข้า Queue timeout=0 (ข้ามถ้า Queue เต็ม — ไม่ block task สำคัญ)
        xQueueSend(xIMUQueue, &d, 0);
    }
}
