#pragma once

// ===== WiFi =====
#define WIFI_SSID        "12345678"
#define WIFI_PASS        "12345678"

// ===== LINE Messaging API (Bot) =====
#define LINE_TOKEN       "zyjDmAadRmIXh319vRJRy3jG3AuDIOyMJGtf8gJ2CLtE0VNfK3ssrAyBTvmwac6xyINGwmJtNHHj8HWtxnen6f4S2wzYORGAtX8A9m9rqxcqtsBqvXyNPiDzSMLnvYiZCdLNJCscYYb/wwnVQ386KAdB04t89/1O/w1cDnyilFU="
#define LINE_USER_ID     "U2041da3d5d7a001af9976117979b42fe"
#define LINE_API_URL     "https://api.line.me/v2/bot/message/push"

// ===== NTP =====
#define NTP_SERVER1      "pool.ntp.org"
#define NTP_SERVER2      "time.nist.gov"
#define NTP_GMT_OFFSET   (7 * 3600)   // GMT+7

// ===== GPIO pins (ESP32-C3 / XIAO ESP32-C3) =====
#define PIN_SDA          6
#define PIN_SCL          7
#define PIN_BUZZER       2   // passive buzzer (tone)
#define PIN_BUTTON       3   // cancel button  (PULLUP)
#define PIN_NTC          0   // ADC pin (GPIO0 = ADC1_CH0 on C3)

// ===== IMU poll rate =====
#define IMU_POLL_MS      50    // 20 Hz

// ===== LPF =====
#define LPF_ALPHA        0.3f  // 0.1=smooth 0.9=raw

// ===== Fall detection thresholds =====
#define FREEFALL_G       0.4f  // magnitude < = freefall
#define IMPACT_G         2.5f  // magnitude > = impact
#define WINDOW_MS        500   // ms after freefall that waits for impact

// ===== Distance alert (VL53L0X) =====
#define DIST_WARN_M     1.5f  // 1.5 m — warn if object closer than this

// ===== Temperature alert (NTC) =====
#define TEMP_WARN_C      38.0f // heatstroke warning threshold °C
// NTC 3950 10k divider params
#define NTC_SERIES_R     10000.0f  // series resistor (10kΩ)
#define NTC_NOMINAL_R    10000.0f  // NTC resistance at 25°C
#define NTC_NOMINAL_T    25.0f     // °C
#define NTC_BETA         3950.0f
#define ADC_MAX          4095.0f   // 12-bit ADC

// ===== Alert timing =====
#define ALERT_COUNTDOWN_MS  15000  // 15 s before 2nd LINE message

// ===== FreeRTOS priorities (higher number = higher priority) =====
// ESP32-C3 configMAX_PRIORITIES = 25
#define PRI_IMU          5
#define PRI_FALL         4
#define PRI_DISTANCE     3
#define PRI_TEMP         3
#define PRI_BUZZER       2
#define PRI_ALERT        2
#define PRI_MONITOR      1

// ===== Buzzer (tone via ledc) =====
#define LEDC_CH          0
#define LEDC_FREQ_HZ     2700
#define LEDC_RES         8     // bits
