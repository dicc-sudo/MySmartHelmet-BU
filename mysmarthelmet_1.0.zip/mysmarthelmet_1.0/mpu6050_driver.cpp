#include "mpu6050_driver.h"
#include <Wire.h>

void mpu6050Init() {
    // Wire.begin() ถูกเรียกใน setup() แล้ว
    Wire.setClock(400000);   // 400 kHz Fast-mode

    // wake up — ล้าง sleep bit
    Wire.beginTransmission(MPU_ADDR);
    Wire.write(MPU_REG_PWR);
    Wire.write(0x00);
    Wire.endTransmission(true);
    delay(100);
}

bool mpu6050Read(imu_data_t *out) {
    // ป้องกัน I2C bus ที่ใช้ร่วมกับ VL53L0X
    if (xWireMutex && xSemaphoreTake(xWireMutex, pdMS_TO_TICKS(10)) != pdTRUE) {
        return false;
    }

    Wire.beginTransmission(MPU_ADDR);
    Wire.write(MPU_REG_ACCEL);
    bool ok = (Wire.endTransmission(false) == 0);

    if (ok) {
        Wire.requestFrom(MPU_ADDR, (uint8_t)14);
        ok = (Wire.available() >= 14);
    }

    if (ok) {
        auto rd16 = [&]() -> int16_t {
            int16_t v = Wire.read() << 8;
            v |= Wire.read();
            return v;
        };
        out->ax = rd16() / ACCEL_SCALE;
        out->ay = rd16() / ACCEL_SCALE;
        out->az = rd16() / ACCEL_SCALE;
        rd16();  // temp — skip
        out->gx = rd16() / GYRO_SCALE;
        out->gy = rd16() / GYRO_SCALE;
        out->gz = rd16() / GYRO_SCALE;
        out->ts = xTaskGetTickCount();
    }

    if (xWireMutex) xSemaphoreGive(xWireMutex);
    return ok;
}
