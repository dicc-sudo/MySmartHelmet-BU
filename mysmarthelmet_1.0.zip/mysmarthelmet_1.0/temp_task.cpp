// #include <Arduino.h>
// #include "ipc.h"
// #include "config.h"
// #include <math.h>

// // ─── NTC Steinhart-Hart (simplified Beta equation) ────────────
// static float ntcReadCelsius() {
//     int raw = analogRead(PIN_NTC);
//     if (raw <= 0) return -999.0f;

//     float r_ntc = NTC_SERIES_R * (float)raw / (ADC_MAX - (float)raw);

//     float steinhart = r_ntc / NTC_NOMINAL_R;
//     steinhart = logf(steinhart);
//     steinhart /= NTC_BETA;
//     steinhart += 1.0f / (NTC_NOMINAL_T + 273.15f);
//     steinhart = 1.0f / steinhart;
//     return steinhart - 273.15f;
// }

// // ─── Task: Temperature Monitor (Priority PRI_TEMP) ─────────────
// void vTempTask(void *pv) {
//     // ESP32 Arduino core ≥ 3.x: analogSetAttenuation ถูกแทนด้วย
//     // analogSetPinAttenuation ต่อ pin หรือตั้งใน setup() แทน
//     analogSetPinAttenuation(PIN_NTC, ADC_ATTENDB_MAX);  // 0–3.3V
//     analogRead(PIN_NTC);   // warm-up
//     vTaskDelay(pdMS_TO_TICKS(200));

//     for (;;) {
//         float t = ntcReadCelsius();

//         temp_data_t td = { t, (uint32_t)xTaskGetTickCount() };
//         xQueueOverwrite(xTempQueue, &td);   // เก็บแค่ค่าล่าสุด

//         if (t > TEMP_WARN_C) {
//             Serial.printf("[TEMP] WARNING %.1f°C\n", t);
//             xEventGroupSetBits(xAlertEvents, TEMP_WARN_BIT);
//         } else {
//             xEventGroupClearBits(xAlertEvents, TEMP_WARN_BIT);
//         }

//         vTaskDelay(pdMS_TO_TICKS(2000));
//     }
// }
#include <Arduino.h>
#include "ipc.h"
#include "config.h"

// ฟังก์ชันอ่านอุณหภูมิแบบง่าย (Map ค่าจาก ADC โดยตรง)
// สูตรนี้แม่นยำพอสำหรับการเตือน Heatstroke และไม่กิน Stack
static float ntcReadCelsius() {
    int raw = analogRead(PIN_NTC);
    
    // ป้องกันค่า Error จากสายหลุดหรือช็อต
    if (raw >= 4092) return 0.0f;   // สายหลุด (Pull-up ดึงไฟเต็ม)
    if (raw <= 5)    return 99.0f;  // ช็อตลงกราวด์

    /* * ใช้การคำนวณแบบ Linear Approximation แทน logf
     * อ้างอิงจาก NTC 10k + Resistor 10k (Voltage Divider)
     * ที่ 25°C ค่า ADC ควรอยู่ประมาณ 2048 (ครึ่งหนึ่งของ 4095)
     */
    // สูตรประมาณค่า: 25องศา + (ค่าเบี่ยงเบนจากจุดกึ่งกลาง)
    // หมายเหตุ: ค่า 0.02f คือค่า Sensitivity โดยประมาณ (อาจปรับได้ตามผลทดสอบ)
    // float temp = 25.0f + (2048 - raw) * 0.025f;
    float temp = 21.0f + (2600 - raw) * 0.025f;

    return temp;
}

void vTempTask(void *pv) {
    // ตั้งค่า ADC ให้รับแรงดันได้ 0-3.3V
    analogSetPinAttenuation(PIN_NTC, ADC_ATTENDB_MAX);
    
    for (;;) {
        float currentTemp = ntcReadCelsius();

        // ส่งข้อมูลเข้า Queue
        temp_data_t td = { currentTemp, (uint32_t)xTaskGetTickCount() };
        xQueueOverwrite(xTempQueue, &td);

        // ตรวจสอบเงื่อนไขแจ้งเตือน
        if (currentTemp > TEMP_WARN_C) {
            Serial.printf("[TEMP] Hot! %.1f C\n", currentTemp);
            xEventGroupSetBits(xAlertEvents, TEMP_WARN_BIT);
        } else {
            xEventGroupClearBits(xAlertEvents, TEMP_WARN_BIT);
        }

        // อ่านค่าทุก 2 วินาที (ไม่จำเป็นต้องอ่านบ่อยเพื่อประหยัด CPU)
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}