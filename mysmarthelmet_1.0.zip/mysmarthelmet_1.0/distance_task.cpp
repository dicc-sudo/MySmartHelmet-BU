// #include <Arduino.h>
// #include "ipc.h"
// #include "config.h"
// #include <VL53L0X.h>

// static VL53L0X sensor;
// static bool sensorOK = false;

// void vl53l0xInit() {
//     if (xWireMutex) xSemaphoreTake(xWireMutex, portMAX_DELAY);
//     sensor.init();
//     sensor.setTimeout(200);
//     sensor.startContinuous(100);
//     sensorOK = true;
//     if (xWireMutex) xSemaphoreGive(xWireMutex);
//     Serial.println("[DIST] VL53L0X ready");
// }

// void vDistanceTask(void *pv) {
//     Serial.printf("[DIST] stack HWM: %d words\n",
//                   uxTaskGetStackHighWaterMark(NULL));

//     if (!sensorOK) {
//         Serial.println("[DIST] sensor not init — task exit");
//         vTaskDelete(NULL);
//     }

//     for (;;) {
//         uint16_t dist_mm = 9999;

//         if (xSemaphoreTake(xWireMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
//             dist_mm = sensor.readRangeContinuousMillimeters();
//             if (sensor.timeoutOccurred()) dist_mm = 9999;
//             xSemaphoreGive(xWireMutex);
//         }

//         dist_data_t dd = { dist_mm, (uint32_t)xTaskGetTickCount() };
//         xQueueOverwrite(xDistQueue, &dd);

//         if (dist_mm < DIST_WARN_MM) {
//             xEventGroupSetBits(xAlertEvents, DIST_WARN_BIT);
//         } else {
//             xEventGroupClearBits(xAlertEvents, DIST_WARN_BIT);
//         }

//         vTaskDelay(pdMS_TO_TICKS(200));
//     }
// }
#include <Arduino.h>
#include "ipc.h"
#include "config.h"
#include <VL53L0X.h>

static VL53L0X sensor;
static bool sensorOK = false;

void vl53l0xInit() {
    // จองคิวสาย I2C -> ตั้งค่าเซนเซอร์ -> คืนคิวสาย
    if (xWireMutex) {
        xSemaphoreTake(xWireMutex, portMAX_DELAY);
        sensor.init();
        sensor.setTimeout(200);
        sensor.startContinuous(100);
        sensorOK = true;
        xSemaphoreGive(xWireMutex);
        
        Serial.println("[DIST] VL53L0X ready");
    }
}

void vDistanceTask(void *pv) {
    // ถ้าเซนเซอร์เริ่มทำงานไม่สำเร็จ ให้จบ Task นี้ไปเลย (Fail-safe)
    if (!sensorOK) {
        Serial.println("[DIST] Sensor error! Task exit.");
        vTaskDelete(NULL);
    }

    for (;;) {
        float dist_m = 99.0f; // ตั้งค่าเริ่มต้นไว้ที่ 99 เมตร (ไกลมาก = ปลอดภัยสุดๆ)

        // 1. ขอใช้สาย I2C (รอไม่เกิน 50ms)
        if (xSemaphoreTake(xWireMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
            
            // อ่านค่าจากเซนเซอร์ (เป็น mm)
            uint16_t raw_mm = sensor.readRangeContinuousMillimeters();
            
            // ถ้าเซนเซอร์ไม่อ่านพลาด (ไม่ Timeout) ให้แปลงเป็นหน่วย "เมตร"
            if (!sensor.timeoutOccurred()) {
                dist_m = raw_mm / 1000.0f; 
            }
            
            // อ่านเสร็จคืนคิวสาย I2C ทันที
            xSemaphoreGive(xWireMutex);
        }

        // 2. เก็บค่าล่าสุดส่งลงกล่อง (Queue)
        dist_data_t dd = { dist_m, (uint32_t)xTaskGetTickCount() };
        xQueueOverwrite(xDistQueue, &dd);

        // 3. ตรวจสอบการแจ้งเตือน (เตือนถ้าระยะ < DIST_WARN_M)
        if (dist_m < DIST_WARN_M) {
            xEventGroupSetBits(xAlertEvents, DIST_WARN_BIT); // ยกธงเตือน
        } else {
            xEventGroupClearBits(xAlertEvents, DIST_WARN_BIT); // เอาธงลง
        }

        // 4. พัก CPU 200ms
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}
