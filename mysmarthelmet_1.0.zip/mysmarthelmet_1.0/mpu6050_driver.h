#pragma once
#include "ipc.h"
#include "config.h"

#define MPU_ADDR      0x68
#define MPU_REG_PWR   0x6B
#define MPU_REG_ACCEL 0x3B
#define ACCEL_SCALE   16384.0f   // ±2g → 16384 LSB/g
#define GYRO_SCALE    131.0f     // ±250°/s → 131 LSB/°/s

// เรียกใน setup() ก่อน task ใดๆ (Wire ต้องเริ่มแล้ว)
void mpu6050Init();

// อ่าน 14 byte burst; ใช้ xWireMutex ภายใน; คืน true ถ้าสำเร็จ
bool mpu6050Read(imu_data_t *out);
