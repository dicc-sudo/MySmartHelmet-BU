#include <Arduino.h>
#include "ipc.h"
#include "config.h"
#include <math.h>

typedef enum { IDLE, FREEFALL } FallState;

// ─── Task: Fall Detection (Priority PRI_FALL) ──────────────────
// รับข้อมูล IMU จาก Queue วิเคราะห์ด้วย state machine
// IDLE → FREEFALL (mag < FREEFALL_G) → IMPACT (mag > IMPACT_G ภายใน WINDOW_MS)
// หากตรวจพบการล้มจริง → set FALL_BIT ใน xAlertEvents
// การใช้ EventGroup แทน direct notify เพราะ Alert และ Buzzer ต้องได้ event พร้อมกัน
void vFallDetectTask(void *pv) {
    imu_data_t  d;
    FallState   state    = IDLE;
    TickType_t  fallTick = 0;
    const TickType_t WIN = pdMS_TO_TICKS(WINDOW_MS);

    for (;;) {
        // block รอ IMU data — ไม่กิน CPU
        xQueueReceive(xIMUQueue, &d, portMAX_DELAY);

        float mag = sqrtf(d.ax_f * d.ax_f +
                          d.ay_f * d.ay_f +
                          d.az_f * d.az_f);

        switch (state) {

        case IDLE:
            if (mag < FREEFALL_G) {
                state    = FREEFALL;
                fallTick = xTaskGetTickCount();
                Serial.printf("[FALL] freefall detected mag=%.2f\n", mag);
            }
            break;

        case FREEFALL:
            if (mag > IMPACT_G) {
                // ตรวจพบการล้มจริง
                Serial.printf("[FALL] IMPACT! mag=%.2f — alerting\n", mag);
                // ใช้ Mutex ตรวจสอบ gIsAlerting ก่อน set bit
                // เพื่อไม่ให้ interrupt alert ที่กำลังดำเนินอยู่
                if (xSemaphoreTake(xAlertMutex, 0) == pdTRUE) {
                    if (!gIsAlerting) {
                        gIsAlerting = true;
                        xSemaphoreGive(xAlertMutex);
                        xEventGroupSetBits(xAlertEvents, FALL_BIT);
                    } else {
                        xSemaphoreGive(xAlertMutex);
                        Serial.println("[FALL] alert already active — skip");
                    }
                }
                state = IDLE;
            } else if (xTaskGetTickCount() - fallTick > WIN) {
                state = IDLE;   // หมด window ไม่ใช่การล้ม
            }
            break;
        }
    }
}
