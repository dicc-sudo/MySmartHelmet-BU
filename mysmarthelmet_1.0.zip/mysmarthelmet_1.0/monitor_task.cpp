#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <time.h>
#include "ipc.h"
#include "config.h"

static void monSendLine(const char *msg) {
    if (WiFi.status() != WL_CONNECTED) return;

    char escaped[512];
    size_t j = 0;
    for (size_t i = 0; msg[i] && j < sizeof(escaped) - 3; i++) {
        if (msg[i] == '\n') { escaped[j++] = '\\'; escaped[j++] = 'n'; }
        else                 { escaped[j++] = msg[i]; }
    }
    escaped[j] = '\0';

    char body[640];
    snprintf(body, sizeof(body),
        "{\"to\":\"" LINE_USER_ID "\","
        "\"messages\":[{\"type\":\"text\",\"text\":\"%s\"}]}", escaped);

    WiFiClientSecure *client = new WiFiClientSecure();
    client->setInsecure();
    HTTPClient http;
    http.begin(*client, LINE_API_URL);
    http.addHeader("Content-Type", "application/json");
    http.addHeader("Authorization", "Bearer " LINE_TOKEN);
    http.setTimeout(8000);
    http.POST(body);
    http.end();
    delete client;
}

void vMonitorTask(void *pv) {
    const TickType_t INTERVAL = pdMS_TO_TICKS(5 * 60 * 1000UL);
    TickType_t xLastReport = xTaskGetTickCount();

    char tsbuf[16];
    char report[400];

    for (;;) {
        Serial.printf("[MON] stack HWM: %d words\n",
                      uxTaskGetStackHighWaterMark(NULL));

        UBaseType_t imuQ = uxQueueMessagesWaiting(xIMUQueue);
        if (imuQ >= 4) Serial.printf("[MON] WARN IMUQueue %d/5\n", imuQ);

        if (WiFi.status() != WL_CONNECTED) {
            Serial.println("[MON] WiFi lost — reconnecting");
            WiFi.reconnect();
            vTaskDelay(pdMS_TO_TICKS(5000));
        }

        if ((xTaskGetTickCount() - xLastReport) >= INTERVAL) {
            xLastReport = xTaskGetTickCount();

            dist_data_t dd = {};
            temp_data_t td = {};
            imu_data_t  id = {};
            xQueuePeek(xDistQueue, &dd, 0);
            xQueuePeek(xTempQueue, &td, 0);
            xQueuePeek(xIMUQueue,  &id, 0);

            struct tm ti;
            if (getLocalTime(&ti, 2000))
                strftime(tsbuf, sizeof(tsbuf), "%H:%M:%S", &ti);
            else
                strncpy(tsbuf, "N/A", sizeof(tsbuf));

            snprintf(report, sizeof(report),
                "📊 [MySmartHelmet] %s\n"
                "IMU:%.2f %.2f %.2f g\n"
                "ระยะ:%d mm อุณหภูมิ:%.1fC\nWiFi:%d dBm",
                tsbuf,
                id.ax_f, id.ay_f, id.az_f,
                dd.distance_mm, td.temp_c, WiFi.RSSI());

            monSendLine(report);
            Serial.println("[MON] report sent");
        }

        vTaskDelay(pdMS_TO_TICKS(10000));
    }
}
